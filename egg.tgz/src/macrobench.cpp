// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("macrobench"); }
int main(){
  announce();
  return lionss_run_workload("macrobench");
}
