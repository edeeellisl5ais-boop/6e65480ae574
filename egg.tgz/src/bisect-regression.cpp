// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("bisect regression"); }
int main(){
  announce();
  return lionss_run_workload("bisect-regression");
}
