// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("compatibility tests\n", stdout);
  return lionss_run_workload("compatibility-tests");
}
