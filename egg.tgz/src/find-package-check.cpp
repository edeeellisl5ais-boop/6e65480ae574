// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("find package check\n", stdout);
  return lionss_run_workload("find-package-check");
}
