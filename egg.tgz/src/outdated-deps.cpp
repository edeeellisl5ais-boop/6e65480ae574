// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("outdated deps"); }
int main(){
  announce();
  return lionss_run_workload("outdated-deps");
}
